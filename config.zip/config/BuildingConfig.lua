-- 插件版本：SG 2.6
-- 该文件由工具自动生成，请不要手动修改
-- 生成时间:2015-04-08 09:01:08
BuildingConfig = {}
BuildingConfig[1] =
	{   
		name = "XXX", 
		icon_animate = "", 
		icon_path = "dragonBuild_1_1.png", 
		obtain_power = 50, 
		hp = 1250, 
		icon = ""
	}
BuildingConfig[2] =
	{   
		name = "XXX", 
		icon_animate = "", 
		icon_path = "dragonBuild_1_2.png", 
		obtain_power = 50, 
		hp = 1250, 
		icon = ""
	}
BuildingConfig[3] =
	{   
		name = "XXX", 
		icon_animate = "", 
		icon_path = "dragonBuild_1_3.png", 
		obtain_power = 50, 
		hp = 1250, 
		icon = ""
	}
BuildingConfig[4] =
	{   
		name = "XXX", 
		icon_animate = "", 
		icon_path = "dragonBuild_1_4.png", 
		obtain_power = 50, 
		hp = 1250, 
		icon = ""
	}
BuildingConfig[5] =
	{   
		name = "XXX", 
		icon_animate = "", 
		icon_path = "dragonBuild_1_5.png", 
		obtain_power = 50, 
		hp = 1250, 
		icon = ""
	}
BuildingConfig[6] =
	{   
		name = "XXX", 
		icon_animate = "", 
		icon_path = "dragonBuild_1_6.png", 
		obtain_power = 50, 
		hp = 1250, 
		icon = ""
	}
BuildingConfig[7] =
	{   
		name = "XXX", 
		icon_animate = "", 
		icon_path = "dragonBuild_1_7.png", 
		obtain_power = 50, 
		hp = 1250, 
		icon = ""
	}
BuildingConfig[8] =
	{   
		name = "XXX", 
		icon_animate = "", 
		icon_path = "dragonBuild_2-1_1.png", 
		obtain_power = 80, 
		hp = 2500, 
		icon = ""
	}
BuildingConfig[9] =
	{   
		name = "XXX", 
		icon_animate = "", 
		icon_path = "dragonBuild_2-1_2.png", 
		obtain_power = 80, 
		hp = 2500, 
		icon = ""
	}
BuildingConfig[10] =
	{   
		name = "XXX", 
		icon_animate = "", 
		icon_path = "dragonBuild_2-2_1.png", 
		obtain_power = 80, 
		hp = 2500, 
		icon = ""
	}
BuildingConfig[11] =
	{   
		name = "XXX", 
		icon_animate = "", 
		icon_path = "dragonBuild_2-2_2.png", 
		obtain_power = 80, 
		hp = 2500, 
		icon = ""
	}
BuildingConfig[12] =
	{   
		name = "XXX", 
		icon_animate = "", 
		icon_path = "dragonBuild_4_1.png", 
		obtain_power = 140, 
		hp = 5000, 
		icon = ""
	}
BuildingConfig[13] =
	{   
		name = "XXX", 
		icon_animate = "", 
		icon_path = "dragonBuild_4_2.png", 
		obtain_power = 140, 
		hp = 5000, 
		icon = ""
	}
BuildingConfig[14] =
	{   
		name = "XXX", 
		icon_animate = "", 
		icon_path = "hellBuild_1_1.png", 
		obtain_power = 55, 
		hp = 1500, 
		icon = ""
	}
BuildingConfig[15] =
	{   
		name = "XXX", 
		icon_animate = "", 
		icon_path = "hellBuild_1_2.png", 
		obtain_power = 55, 
		hp = 1500, 
		icon = ""
	}
BuildingConfig[16] =
	{   
		name = "XXX", 
		icon_animate = "", 
		icon_path = "hellBuild_1_3.png", 
		obtain_power = 55, 
		hp = 1500, 
		icon = ""
	}
BuildingConfig[17] =
	{   
		name = "XXX", 
		icon_animate = "", 
		icon_path = "hellBuild_1_4.png", 
		obtain_power = 55, 
		hp = 1500, 
		icon = ""
	}
BuildingConfig[18] =
	{   
		name = "XXX", 
		icon_animate = "", 
		icon_path = "hellBuild_1_5.png", 
		obtain_power = 55, 
		hp = 1500, 
		icon = ""
	}
BuildingConfig[19] =
	{   
		name = "XXX", 
		icon_animate = "", 
		icon_path = "hellBuild_1_6.png", 
		obtain_power = 55, 
		hp = 1500, 
		icon = ""
	}
BuildingConfig[20] =
	{   
		name = "XXX", 
		icon_animate = "", 
		icon_path = "hellBuild_2-1_1.png",
		obtain_power = 88, 
		hp = 3000, 
		icon = ""
	}
BuildingConfig[21] =
	{   
		name = "XXX", 
		icon_animate = "", 
		icon_path = "hellBuild_2-1_2.png", 
		obtain_power = 88, 
		hp = 3000, 
		icon = ""
	}
BuildingConfig[22] =
	{   
		name = "XXX", 
		icon_animate = "", 
		icon_path = "hellBuild_2-1_3.png", 
		obtain_power = 88, 
		hp = 3000, 
		icon = ""
	}
BuildingConfig[23] =
	{   
		name = "XXX", 
		icon_animate = "", 
		icon_path = "hellBuild_2-2_1.png", 
		obtain_power = 88, 
		hp = 3000, 
		icon = ""
	}
BuildingConfig[24] =
	{   
		name = "XXX", 
		icon_animate = "", 
		icon_path = "hellBuild_2-2_2.png", 
		obtain_power = 88, 
		hp = 3000, 
		icon = ""
	}
BuildingConfig[25] =
	{   
		name = "XXX", 
		icon_animate = "", 
		icon_path = "hellBuild_2-2_3.png", 
		obtain_power = 88, 
		hp = 3000, 
		icon = ""
	}
BuildingConfig[26] =
	{   
		name = "XXX", 
		icon_animate = "", 
		icon_path = "hellBuild_2-2_4.png", 
		obtain_power = 88, 
		hp = 3000, 
		icon = ""
	}
BuildingConfig[27] =
	{   
		name = "XXX", 
		icon_animate = "", 
		icon_path = "hellBuild_4_1.png", 
		obtain_power = 154, 
		hp = 6000, 
		icon = ""
	}
BuildingConfig[28] =
	{   
		name = "XXX", 
		icon_animate = "", 
		icon_path = "hellBuild_4_2.png", 
		obtain_power = 154, 
		hp = 6000, 
		icon = ""
	}
BuildingConfig[29] =
	{   
		name = "XXX", 
		icon_animate = "", 
		icon_path = "hellBuild_4_3.png", 
		obtain_power = 154, 
		hp = 6000, 
		icon = ""
	}
BuildingConfig[30] =
	{   
		name = "XXX", 
		icon_animate = "", 
		icon_path = "hellBuild_4_4.png", 
		obtain_power = 154, 
		hp = 6000, 
		icon = ""
	}
BuildingConfig[31] =
	{   
		name = "XXX", 
		icon_animate = "", 
		icon_path = "skyBuild_1_1.png", 
		obtain_power = 60, 
		hp = 1750, 
		icon = ""
	}
BuildingConfig[32] =
	{   
		name = "XXX", 
		icon_animate = "", 
		icon_path = "skyBuild_1_2.png", 
		obtain_power = 60, 
		hp = 1750, 
		icon = ""
	}
BuildingConfig[33] =
	{   
		name = "XXX", 
		icon_animate = "", 
		icon_path = "skyBuild_1_3.png", 
		obtain_power = 60, 
		hp = 1750, 
		icon = ""
	}
BuildingConfig[34] =
	{   
		name = "XXX", 
		icon_animate = "", 
		icon_path = "skyBuild_1_4.png", 
		obtain_power = 60, 
		hp = 1750, 
		icon = ""
	}
BuildingConfig[35] =
	{   
		name = "XXX", 
		icon_animate = "", 
		icon_path = "skyBuild_2-1_1.png", 
		obtain_power = 96, 
		hp = 3500, 
		icon = ""
	}
BuildingConfig[36] =
	{   
		name = "XXX", 
		icon_animate = "", 
		icon_path = "skyBuild_2-1_2.png", 
		obtain_power = 96, 
		hp = 3500, 
		icon = ""
	}
BuildingConfig[37] =
	{   
		name = "XXX", 
		icon_animate = "", 
		icon_path = "skyBuild_2-1_3.png", 
		obtain_power = 96, 
		hp = 3500, 
		icon = ""
	}
BuildingConfig[38] =
	{   
		name = "XXX", 
		icon_animate = "", 
		icon_path = "skyBuild_2-2_1.png", 
		obtain_power = 96, 
		hp = 3500, 
		icon = ""
	}
BuildingConfig[39] =
	{   
		name = "XXX", 
		icon_animate = "", 
		icon_path = "skyBuild_2-2_2.png", 
		obtain_power = 96, 
		hp = 3500, 
		icon = ""
	}
BuildingConfig[40] =
	{   
		name = "XXX", 
		icon_animate = "", 
		icon_path = "skyBuild_4_1.png", 
		obtain_power = 168, 
		hp = 7000, 
		icon = ""
	}
BuildingConfig[41] =
	{   
		name = "XXX", 
		icon_animate = "", 
		icon_path = "skyBuild_4_2.png", 
		obtain_power = 168, 
		hp = 7000, 
		icon = ""
	}
BuildingConfig[42] =
	{   
		name = "XXX", 
		icon_animate = "", 
		icon_path = "skyBuild_4_3.png", 
		obtain_power = 168, 
		hp = 7000, 
		icon = ""
	}
BuildingConfig[43] =
	{   
		name = "XXX", 
		icon_animate = "", 
		icon_path = "skyBuild_4_4.png", 
		obtain_power = 168, 
		hp = 7000, 
		icon = ""
	}
BuildingConfig[44] =
	{   
		name = "XXX", 
		icon_animate = "", 
		icon_path = "skyBuild_4_5.png", 
		obtain_power = 168, 
		hp = 7000, 
		icon = ""
	}
BuildingConfig[45] =
	{   
		name = "XXX", 
		icon_animate = "", 
		icon_path = "yellowBuild_1_1.png", 
		obtain_power = 65, 
		hp = 2000, 
		icon = ""
	}
BuildingConfig[46] =
	{   
		name = "XXX", 
		icon_animate = "", 
		icon_path = "yellowBuild_1_2.png", 
		obtain_power = 65, 
		hp = 2000, 
		icon = ""
	}
BuildingConfig[47] =
	{   
		name = "XXX", 
		icon_animate = "", 
		icon_path = "yellowBuild_1_3.png", 
		obtain_power = 65, 
		hp = 2000, 
		icon = ""
	}
BuildingConfig[48] =
	{   
		name = "XXX", 
		icon_animate = "", 
		icon_path = "yellowBuild_1_4.png", 
		obtain_power = 65, 
		hp = 2000, 
		icon = ""
	}
BuildingConfig[49] =
	{   
		name = "XXX", 
		icon_animate = "", 
		icon_path = "yellowBuild_1_5.png", 
		obtain_power = 65, 
		hp = 2000, 
		icon = ""
	}
BuildingConfig[50] =
	{   
		name = "XXX", 
		icon_animate = "", 
		icon_path = "yellowBuild_2-1_1.png", 
		obtain_power = 104, 
		hp = 4000, 
		icon = ""
	}
BuildingConfig[51] =
	{   
		name = "XXX", 
		icon_animate = "", 
		icon_path = "yellowBuild_2-1_2.png", 
		obtain_power = 104, 
		hp = 4000, 
		icon = ""
	}
BuildingConfig[52] =
	{   
		name = "XXX", 
		icon_animate = "", 
		icon_path = "yellowBuild_2-1_3.png", 
		obtain_power = 104, 
		hp = 4000, 
		icon = ""
	}
BuildingConfig[53] =
	{   
		name = "XXX", 
		icon_animate = "", 
		icon_path = "yellowBuild_2-1_4.png", 
		obtain_power = 104, 
		hp = 4000, 
		icon = ""
	}
BuildingConfig[54] =
	{   
		name = "XXX", 
		icon_animate = "", 
		icon_path = "yellowBuild_2-1_5.png", 
		obtain_power = 104, 
		hp = 4000, 
		icon = ""
	}
BuildingConfig[55] =
	{   
		name = "XXX", 
		icon_animate = "", 
		icon_path = "yellowBuild_2-2_1.png", 
		obtain_power = 104, 
		hp = 4000, 
		icon = ""
	}
BuildingConfig[56] =
	{   
		name = "XXX", 
		icon_animate = "", 
		icon_path = "yellowBuild_2-2_2.png", 
		obtain_power = 104, 
		hp = 4000, 
		icon = ""
	}
BuildingConfig[57] =
	{   
		name = "XXX", 
		icon_animate = "", 
		icon_path = "yellowBuild_2-2_3.png", 
		obtain_power = 104, 
		hp = 4000, 
		icon = ""
	}
BuildingConfig[58] =
	{   
		name = "XXX", 
		icon_animate = "", 
		icon_path = "yellowBuild_2-2_4.png", 
		obtain_power = 104, 
		hp = 4000, 
		icon = ""
	}
BuildingConfig[59] =
	{   
		name = "XXX", 
		icon_animate = "", 
		icon_path = "yellowBuild_2-2_5.png", 
		obtain_power = 104, 
		hp = 4000, 
		icon = ""
	}
BuildingConfig[60] =
	{   
		name = "XXX", 
		icon_animate = "", 
		icon_path = "yellowBuild_4_1.png", 
		obtain_power = 182, 
		hp = 8000, 
		icon = ""
	}
BuildingConfig[61] =
	{   
		name = "XXX", 
		icon_animate = "", 
		icon_path = "yellowBuild_4_2.png", 
		obtain_power = 182, 
		hp = 8000, 
		icon = ""
	}
BuildingConfig[62] =
	{   
		name = "XXX", 
		icon_animate = "", 
		icon_path = "yellowBuild_4_3.png", 
		obtain_power = 182, 
		hp = 8000, 
		icon = ""
	}
BuildingConfig[63] =
	{   
		name = "XXX", 
		icon_animate = "", 
		icon_path = "skyBuild_1_5.png", 
		obtain_power = 60, 
		hp = 1750, 
		icon = ""
	}
BuildingConfig[64] =
	{   
		name = "XXX", 
		icon_animate = "", 
		icon_path = "skyBuild_1_6.png", 
		obtain_power = 60, 
		hp = 1750, 
		icon = ""
	}
BuildingConfig[65] =
	{   
		name = "XXX", 
		icon_animate = "", 
		icon_path = "skyBuild_2-1_4.png", 
		obtain_power = 96, 
		hp = 3500, 
		icon = ""
	}
BuildingConfig[66] =
	{   
		name = "XXX", 
		icon_animate = "", 
		icon_path = "skyBuild_2_2_3.png", 
		obtain_power = 96, 
		hp = 3500, 
		icon = ""
	}


function BuildingConfig.name(id)
	return BuildingConfig[id].name
end

function BuildingConfig.icon_animate(id)
	return BuildingConfig[id].icon_animate
end

function BuildingConfig.icon_path(id)
	return BuildingConfig[id].icon_path
end

function BuildingConfig.obtain_power(id)
	return BuildingConfig[id].obtain_power
end

function BuildingConfig.hp(id)
	return BuildingConfig[id].hp
end

function BuildingConfig.icon(id)
	return BuildingConfig[id].icon
end

        