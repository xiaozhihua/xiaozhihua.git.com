-- 插件版本：SG 2.6
-- 该文件由工具自动生成，请不要手动修改
-- 生成时间:2014-11-17 11:31:14
LevelMonsterConfig = {}
LevelMonsterConfig[101] =
	{   
		pass_id = 1, 
		type_count = {2,10}
	}
LevelMonsterConfig[102] =
	{   
		pass_id = 1, 
		type_count = {2,8, 3,2}
	}
LevelMonsterConfig[103] =
	{   
		pass_id = 1, 
		type_count = {2,6, 3,4}
	}
LevelMonsterConfig[104] =
	{   
		pass_id = 1, 
		type_count = {2,4, 3,6}
	}
LevelMonsterConfig[105] =
	{   
		pass_id = 1, 
		type_count = {2,2,3,8}
	}
LevelMonsterConfig[106] =
	{   
		pass_id = 1, 
		type_count = {2,10}
	}
LevelMonsterConfig[107] =
	{   
		pass_id = 1, 
		type_count = {2,8, 1,2}
	}
LevelMonsterConfig[108] =
	{   
		pass_id = 1, 
		type_count = {3,5,5,5}
	}
LevelMonsterConfig[109] =
	{   
		pass_id = 1, 
		type_count = {2,4,6,5}
	}
LevelMonsterConfig[110] =
	{   
		pass_id = 1, 
		type_count = {8,1}
	}
LevelMonsterConfig[201] =
	{   
		pass_id = 2, 
		type_count = {3,10}
	}
LevelMonsterConfig[202] =
	{   
		pass_id = 2, 
		type_count = {5,5,5,2}
	}
LevelMonsterConfig[203] =
	{   
		pass_id = 2, 
		type_count = {1,5,2,5}
	}
LevelMonsterConfig[204] =
	{   
		pass_id = 2, 
		type_count = {1,5,3,5}
	}
LevelMonsterConfig[205] =
	{   
		pass_id = 2, 
		type_count = {2,4,5,6}
	}
LevelMonsterConfig[206] =
	{   
		pass_id = 2, 
		type_count = {2,2,5,8}
	}
LevelMonsterConfig[207] =
	{   
		pass_id = 2, 
		type_count = {2,4,6,6}
	}
LevelMonsterConfig[208] =
	{   
		pass_id = 2, 
		type_count = {5,4,3,6}
	}
LevelMonsterConfig[209] =
	{   
		pass_id = 2, 
		type_count = {1,5,4,5}
	}
LevelMonsterConfig[210] =
	{   
		pass_id = 2, 
		type_count = {3,5,4,5}
	}
LevelMonsterConfig[211] =
	{   
		pass_id = 2, 
		type_count = {6,4,3,6}
	}
LevelMonsterConfig[212] =
	{   
		pass_id = 2, 
		type_count = {2,4,4,6}
	}
LevelMonsterConfig[213] =
	{   
		pass_id = 2, 
		type_count = {1,4,6,6}
	}
LevelMonsterConfig[214] =
	{   
		pass_id = 2, 
		type_count = {6,8,2,4}
	}
LevelMonsterConfig[215] =
	{   
		pass_id = 2, 
		type_count = {5,5,8,1}
	}
LevelMonsterConfig[301] =
	{   
		pass_id = 3, 
		type_count = {3,10}
	}
LevelMonsterConfig[302] =
	{   
		pass_id = 3, 
		type_count = {2,5,5,5}
	}
LevelMonsterConfig[303] =
	{   
		pass_id = 3, 
		type_count = {1,5,5,5}
	}
LevelMonsterConfig[304] =
	{   
		pass_id = 3, 
		type_count = {2,5,1,5}
	}
LevelMonsterConfig[305] =
	{   
		pass_id = 3, 
		type_count = {5,5,2,5}
	}
LevelMonsterConfig[306] =
	{   
		pass_id = 3, 
		type_count = {6,8,1,2}
	}
LevelMonsterConfig[307] =
	{   
		pass_id = 3, 
		type_count = {1,4,6,6}
	}
LevelMonsterConfig[308] =
	{   
		pass_id = 3, 
		type_count = {3,6,3,4}
	}
LevelMonsterConfig[309] =
	{   
		pass_id = 3, 
		type_count = {1,5,4,5}
	}
LevelMonsterConfig[310] =
	{   
		pass_id = 3, 
		type_count = {8,1}
	}
LevelMonsterConfig[311] =
	{   
		pass_id = 3, 
		type_count = {6,10}
	}
LevelMonsterConfig[312] =
	{   
		pass_id = 3, 
		type_count = {4,10}
	}
LevelMonsterConfig[313] =
	{   
		pass_id = 3, 
		type_count = {5,6,1,4}
	}
LevelMonsterConfig[314] =
	{   
		pass_id = 3, 
		type_count = {2,8,4,2}
	}
LevelMonsterConfig[315] =
	{   
		pass_id = 3, 
		type_count = {8,1}
	}
LevelMonsterConfig[316] =
	{   
		pass_id = 3, 
		type_count = {6,4,3,6}
	}
LevelMonsterConfig[317] =
	{   
		pass_id = 3, 
		type_count = {2,8,2,4}
	}
LevelMonsterConfig[318] =
	{   
		pass_id = 3, 
		type_count = {9,1}
	}
LevelMonsterConfig[319] =
	{   
		pass_id = 3, 
		type_count = {2,8,4,4}
	}
LevelMonsterConfig[320] =
	{   
		pass_id = 3, 
		type_count = {1,9,13,1}
	}
LevelMonsterConfig[401] =
	{   
		pass_id = 4, 
		type_count = {1,10}
	}
LevelMonsterConfig[402] =
	{   
		pass_id = 4, 
		type_count = {2,4,5,6}
	}
LevelMonsterConfig[403] =
	{   
		pass_id = 4, 
		type_count = {1,4,2,6}
	}
LevelMonsterConfig[404] =
	{   
		pass_id = 4, 
		type_count = {1,4,5,6}
	}
LevelMonsterConfig[405] =
	{   
		pass_id = 4, 
		type_count = {4,4,5,6}
	}
LevelMonsterConfig[406] =
	{   
		pass_id = 4, 
		type_count = {2,6,4,6}
	}
LevelMonsterConfig[407] =
	{   
		pass_id = 4, 
		type_count = {3,10,4,5}
	}
LevelMonsterConfig[408] =
	{   
		pass_id = 4, 
		type_count = {5,4,2,6}
	}
LevelMonsterConfig[409] =
	{   
		pass_id = 4, 
		type_count = {2,5,3,5}
	}
LevelMonsterConfig[410] =
	{   
		pass_id = 4, 
		type_count = {8,1,9,1}
	}
LevelMonsterConfig[411] =
	{   
		pass_id = 4, 
		type_count = {3,4,4,6}
	}
LevelMonsterConfig[412] =
	{   
		pass_id = 4, 
		type_count = {4,6,5,4}
	}
LevelMonsterConfig[413] =
	{   
		pass_id = 4, 
		type_count = {4,7,5,6}
	}
LevelMonsterConfig[414] =
	{   
		pass_id = 4, 
		type_count = {1,8,4,4}
	}
LevelMonsterConfig[415] =
	{   
		pass_id = 4, 
		type_count = {7,4,5,6}
	}
LevelMonsterConfig[416] =
	{   
		pass_id = 4, 
		type_count = {1,10,5,5}
	}
LevelMonsterConfig[417] =
	{   
		pass_id = 4, 
		type_count = {4,7,6,5}
	}
LevelMonsterConfig[418] =
	{   
		pass_id = 4, 
		type_count = {2,20}
	}
LevelMonsterConfig[419] =
	{   
		pass_id = 4, 
		type_count = {1,15}
	}
LevelMonsterConfig[420] =
	{   
		pass_id = 4, 
		type_count = {9,1,7,1}
	}
LevelMonsterConfig[501] =
	{   
		pass_id = 5, 
		type_count = {4,10}
	}
LevelMonsterConfig[502] =
	{   
		pass_id = 5, 
		type_count = {1,5,5,5}
	}
LevelMonsterConfig[503] =
	{   
		pass_id = 5, 
		type_count = {1,6,5,4}
	}
LevelMonsterConfig[504] =
	{   
		pass_id = 5, 
		type_count = {2,5,6,5}
	}
LevelMonsterConfig[505] =
	{   
		pass_id = 5, 
		type_count = {5,7,2,3}
	}
LevelMonsterConfig[506] =
	{   
		pass_id = 5, 
		type_count = {5,8,1,2}
	}
LevelMonsterConfig[507] =
	{   
		pass_id = 5, 
		type_count = {5,5,6,5}
	}
LevelMonsterConfig[508] =
	{   
		pass_id = 5, 
		type_count = {2,6,3,4}
	}
LevelMonsterConfig[509] =
	{   
		pass_id = 5, 
		type_count = {6,5,4,5}
	}
LevelMonsterConfig[510] =
	{   
		pass_id = 5, 
		type_count = {11,1}
	}
LevelMonsterConfig[511] =
	{   
		pass_id = 5, 
		type_count = {2,5,4,5}
	}
LevelMonsterConfig[512] =
	{   
		pass_id = 5, 
		type_count = {6,15}
	}
LevelMonsterConfig[513] =
	{   
		pass_id = 5, 
		type_count = {2,5,5,10}
	}
LevelMonsterConfig[514] =
	{   
		pass_id = 5, 
		type_count = {2,8,3,7}
	}
LevelMonsterConfig[515] =
	{   
		pass_id = 5, 
		type_count = {12,1,10,1}
	}
LevelMonsterConfig[516] =
	{   
		pass_id = 5, 
		type_count = {5,5,6,10}
	}
LevelMonsterConfig[517] =
	{   
		pass_id = 5, 
		type_count = {2,10,3,15}
	}
LevelMonsterConfig[518] =
	{   
		pass_id = 5, 
		type_count = {1,10,2,10}
	}
LevelMonsterConfig[519] =
	{   
		pass_id = 5, 
		type_count = {3,5,4,10}
	}
LevelMonsterConfig[520] =
	{   
		pass_id = 5, 
		type_count = {15,1}
	}
LevelMonsterConfig[601] =
	{   
		pass_id = 6, 
		type_count = {6,10}
	}
LevelMonsterConfig[602] =
	{   
		pass_id = 6, 
		type_count = {2,10}
	}
LevelMonsterConfig[603] =
	{   
		pass_id = 6, 
		type_count = {1,6,6,4}
	}
LevelMonsterConfig[604] =
	{   
		pass_id = 6, 
		type_count = {5,4,1,6}
	}
LevelMonsterConfig[605] =
	{   
		pass_id = 6, 
		type_count = {6,4,1,6}
	}
LevelMonsterConfig[606] =
	{   
		pass_id = 6, 
		type_count = {2,10}
	}
LevelMonsterConfig[607] =
	{   
		pass_id = 6, 
		type_count = {5,5,3,5}
	}
LevelMonsterConfig[608] =
	{   
		pass_id = 6, 
		type_count = {3,5,4,5}
	}
LevelMonsterConfig[609] =
	{   
		pass_id = 6, 
		type_count = {1,5,2,5}
	}
LevelMonsterConfig[610] =
	{   
		pass_id = 6, 
		type_count = {6,5,12,1}
	}
LevelMonsterConfig[611] =
	{   
		pass_id = 6, 
		type_count = {6,4,5,6}
	}
LevelMonsterConfig[612] =
	{   
		pass_id = 6, 
		type_count = {4,10}
	}
LevelMonsterConfig[613] =
	{   
		pass_id = 6, 
		type_count = {4,1,5,10}
	}
LevelMonsterConfig[614] =
	{   
		pass_id = 6, 
		type_count = {5,10,6,5}
	}
LevelMonsterConfig[615] =
	{   
		pass_id = 6, 
		type_count = {7,1,11,1}
	}
LevelMonsterConfig[616] =
	{   
		pass_id = 6, 
		type_count = {4,6,5,9}
	}
LevelMonsterConfig[617] =
	{   
		pass_id = 6, 
		type_count = {2,10,4,5}
	}
LevelMonsterConfig[618] =
	{   
		pass_id = 6, 
		type_count = {3,5,4,10}
	}
LevelMonsterConfig[619] =
	{   
		pass_id = 6, 
		type_count = {5,10,6,10}
	}
LevelMonsterConfig[620] =
	{   
		pass_id = 6, 
		type_count = {5,10,11,1}
	}
LevelMonsterConfig[701] =
	{   
		pass_id = 7, 
		type_count = {1,10}
	}
LevelMonsterConfig[702] =
	{   
		pass_id = 7, 
		type_count = {2,5,5,5}
	}
LevelMonsterConfig[703] =
	{   
		pass_id = 7, 
		type_count = {1,6,5,4}
	}
LevelMonsterConfig[704] =
	{   
		pass_id = 7, 
		type_count = {2,6,6,4}
	}
LevelMonsterConfig[705] =
	{   
		pass_id = 7, 
		type_count = {5,61,4}
	}
LevelMonsterConfig[706] =
	{   
		pass_id = 7, 
		type_count = {2,8,3,2}
	}
LevelMonsterConfig[707] =
	{   
		pass_id = 7, 
		type_count = {6,10}
	}
LevelMonsterConfig[708] =
	{   
		pass_id = 7, 
		type_count = {3,8,4,2}
	}
LevelMonsterConfig[709] =
	{   
		pass_id = 7, 
		type_count = {1,6,2,4}
	}
LevelMonsterConfig[710] =
	{   
		pass_id = 7, 
		type_count = {10,1}
	}
LevelMonsterConfig[711] =
	{   
		pass_id = 7, 
		type_count = {6,4,5,6}
	}
LevelMonsterConfig[712] =
	{   
		pass_id = 7, 
		type_count = {3,10,5,5}
	}
LevelMonsterConfig[713] =
	{   
		pass_id = 7, 
		type_count = {4,5,6,10}
	}
LevelMonsterConfig[714] =
	{   
		pass_id = 7, 
		type_count = {3,10,1,10}
	}
LevelMonsterConfig[715] =
	{   
		pass_id = 7, 
		type_count = {9,1}
	}
LevelMonsterConfig[716] =
	{   
		pass_id = 7, 
		type_count = {3,20}
	}
LevelMonsterConfig[717] =
	{   
		pass_id = 7, 
		type_count = {1,4,6,6}
	}
LevelMonsterConfig[718] =
	{   
		pass_id = 7, 
		type_count = {5,5,4,5,6,5}
	}
LevelMonsterConfig[719] =
	{   
		pass_id = 7, 
		type_count = {6,10,1,10}
	}
LevelMonsterConfig[720] =
	{   
		pass_id = 7, 
		type_count = {15,1}
	}
LevelMonsterConfig[801] =
	{   
		pass_id = 8, 
		type_count = {1,5,2,5}
	}
LevelMonsterConfig[802] =
	{   
		pass_id = 8, 
		type_count = {5,10}
	}
LevelMonsterConfig[803] =
	{   
		pass_id = 8, 
		type_count = {2,6,6,4}
	}
LevelMonsterConfig[804] =
	{   
		pass_id = 8, 
		type_count = {1,6,2,4}
	}
LevelMonsterConfig[805] =
	{   
		pass_id = 8, 
		type_count = {6,5,5,5}
	}
LevelMonsterConfig[806] =
	{   
		pass_id = 8, 
		type_count = {2,6,1,6}
	}
LevelMonsterConfig[807] =
	{   
		pass_id = 8, 
		type_count = {5,5,4,5}
	}
LevelMonsterConfig[808] =
	{   
		pass_id = 8, 
		type_count = {3,4,5,6}
	}
LevelMonsterConfig[809] =
	{   
		pass_id = 8, 
		type_count = {4,4,5,6}
	}
LevelMonsterConfig[810] =
	{   
		pass_id = 8, 
		type_count = {2,5,12,1}
	}
LevelMonsterConfig[811] =
	{   
		pass_id = 8, 
		type_count = {2,5,3,10}
	}
LevelMonsterConfig[812] =
	{   
		pass_id = 8, 
		type_count = {2,8,3,4}
	}
LevelMonsterConfig[813] =
	{   
		pass_id = 8, 
		type_count = {3,10,4,10}
	}
LevelMonsterConfig[814] =
	{   
		pass_id = 8, 
		type_count = {1,5,6,10}
	}
LevelMonsterConfig[815] =
	{   
		pass_id = 8, 
		type_count = {10,1,4,10}
	}
LevelMonsterConfig[816] =
	{   
		pass_id = 8, 
		type_count = {6,10,4,10}
	}
LevelMonsterConfig[817] =
	{   
		pass_id = 8, 
		type_count = {4,5,6,10}
	}
LevelMonsterConfig[818] =
	{   
		pass_id = 8, 
		type_count = {2,10,3,10}
	}
LevelMonsterConfig[819] =
	{   
		pass_id = 8, 
		type_count = {4,10,2,10}
	}
LevelMonsterConfig[820] =
	{   
		pass_id = 8, 
		type_count = {11,1,12,1}
	}
LevelMonsterConfig[821] =
	{   
		pass_id = 8, 
		type_count = {5,20}
	}
LevelMonsterConfig[822] =
	{   
		pass_id = 8, 
		type_count = {1,10,2,10}
	}
LevelMonsterConfig[823] =
	{   
		pass_id = 8, 
		type_count = {3,15,4,5}
	}
LevelMonsterConfig[824] =
	{   
		pass_id = 8, 
		type_count = {5,10,6,10}
	}
LevelMonsterConfig[825] =
	{   
		pass_id = 8, 
		type_count = {8,1,9,1,10,1,111,1,12,1}
	}
LevelMonsterConfig[901] =
	{   
		pass_id = 9, 
		type_count = {2,10,5,10}
	}
LevelMonsterConfig[902] =
	{   
		pass_id = 9, 
		type_count = {1,15,5,5}
	}
LevelMonsterConfig[903] =
	{   
		pass_id = 9, 
		type_count = {1,4,5,6}
	}
LevelMonsterConfig[904] =
	{   
		pass_id = 9, 
		type_count = {1,15,6,5}
	}
LevelMonsterConfig[905] =
	{   
		pass_id = 9, 
		type_count = {2,10,5,10}
	}
LevelMonsterConfig[906] =
	{   
		pass_id = 9, 
		type_count = {7,1}
	}
LevelMonsterConfig[907] =
	{   
		pass_id = 9, 
		type_count = {8,1}
	}
LevelMonsterConfig[908] =
	{   
		pass_id = 9, 
		type_count = {9,1}
	}
LevelMonsterConfig[909] =
	{   
		pass_id = 9, 
		type_count = {10,1}
	}
LevelMonsterConfig[910] =
	{   
		pass_id = 9, 
		type_count = {11,1}
	}
LevelMonsterConfig[911] =
	{   
		pass_id = 9, 
		type_count = {12,1}
	}
LevelMonsterConfig[912] =
	{   
		pass_id = 9, 
		type_count = {7,1,8,1}
	}
LevelMonsterConfig[913] =
	{   
		pass_id = 9, 
		type_count = {8,1,9,1}
	}
LevelMonsterConfig[914] =
	{   
		pass_id = 9, 
		type_count = {9,1,10,1}
	}
LevelMonsterConfig[915] =
	{   
		pass_id = 9, 
		type_count = {10,1,11,1}
	}
LevelMonsterConfig[916] =
	{   
		pass_id = 9, 
		type_count = {11,1,12,1}
	}
LevelMonsterConfig[917] =
	{   
		pass_id = 9, 
		type_count = {1,10,7,3}
	}
LevelMonsterConfig[918] =
	{   
		pass_id = 9, 
		type_count = {2,10,8,3}
	}
LevelMonsterConfig[919] =
	{   
		pass_id = 9, 
		type_count = {3,10,9,3}
	}
LevelMonsterConfig[920] =
	{   
		pass_id = 9, 
		type_count = {10,5,11,3,12,1}
	}
LevelMonsterConfig[1001] =
	{   
		pass_id = 10, 
		type_count = {6,20}
	}
LevelMonsterConfig[1002] =
	{   
		pass_id = 10, 
		type_count = {2,10,3,10}
	}
LevelMonsterConfig[1003] =
	{   
		pass_id = 10, 
		type_count = {4,5,5,15}
	}
LevelMonsterConfig[1004] =
	{   
		pass_id = 10, 
		type_count = {1,5,2,15}
	}
LevelMonsterConfig[1005] =
	{   
		pass_id = 10, 
		type_count = {7,1,4,15}
	}
LevelMonsterConfig[1006] =
	{   
		pass_id = 10, 
		type_count = {1,10,8,2}
	}
LevelMonsterConfig[1007] =
	{   
		pass_id = 10, 
		type_count = {3,10,9,2}
	}
LevelMonsterConfig[1008] =
	{   
		pass_id = 10, 
		type_count = {4,20}
	}
LevelMonsterConfig[1009] =
	{   
		pass_id = 10, 
		type_count = {8,3,7,3}
	}
LevelMonsterConfig[1010] =
	{   
		pass_id = 10, 
		type_count = {1,10,7,1,2,10,8,1}
	}
LevelMonsterConfig[1011] =
	{   
		pass_id = 10, 
		type_count = {3,10,9,1,4,10,10,1}
	}
LevelMonsterConfig[1012] =
	{   
		pass_id = 10, 
		type_count = {5,10,11,1,6,10,12,1}
	}
LevelMonsterConfig[1013] =
	{   
		pass_id = 10, 
		type_count = {4,20,5,10}
	}
LevelMonsterConfig[1014] =
	{   
		pass_id = 10, 
		type_count = {14,1}
	}
LevelMonsterConfig[1015] =
	{   
		pass_id = 10, 
		type_count = {4,20,7,1}
	}
LevelMonsterConfig[1016] =
	{   
		pass_id = 10, 
		type_count = {5,15,9,2}
	}
LevelMonsterConfig[1017] =
	{   
		pass_id = 10, 
		type_count = {6,10,10,3}
	}
LevelMonsterConfig[1018] =
	{   
		pass_id = 10, 
		type_count = {2,5,11,4}
	}
LevelMonsterConfig[1019] =
	{   
		pass_id = 10, 
		type_count = {12,5}
	}
LevelMonsterConfig[1020] =
	{   
		pass_id = 10, 
		type_count = {14,16,10}
	}


function LevelMonsterConfig.pass_id(id)
	return LevelMonsterConfig[id].pass_id
end

function LevelMonsterConfig.type_count(id)
	return LevelMonsterConfig[id].type_count
end

        