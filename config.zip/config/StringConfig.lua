-- 插件版本：SG 2.6
-- 该文件由工具自动生成，请不要手动修改
-- 生成时间:2015-04-07 10:06:11
StringConfig = {}
StringConfig[101] =
	{   
		id = 101, 
		simplified_chinese = "花果山猴子之一，善用石头攻击（因为香蕉太贵了）", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[102] =
	{   
		id = 102, 
		simplified_chinese = "我的丝，绑住你的双脚，却绑住不了你的心", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[103] =
	{   
		id = 103, 
		simplified_chinese = "天神之一，挥一挥拂尘，金星破碎时会溅射周围的敌人", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[104] =
	{   
		id = 104, 
		simplified_chinese = "天神之一，擅长雷电攻击敌人;被动：被攻击时，万雷奔放，持续一段时间", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[105] =
	{   
		id = 105, 
		simplified_chinese = "齐天大圣，挥舞金箍棒怒砸大地，有机率对敌人造成暴击", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[106] =
	{   
		id = 106, 
		simplified_chinese = "东海龙王敖广，挥一挥龙杖便可唤起水柱将敌人冲上天", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[107] =
	{   
		id = 107, 
		simplified_chinese = "前身天蓬元帅，笨拙的身躯挥舞着九齿钉耙，威力惊人", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[108] =
	{   
		id = 108, 
		simplified_chinese = "牛魔王之子，擅用三味真火，波及范围甚大", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[109] =
	{   
		id = 109, 
		simplified_chinese = "天庭最美仙女，有着妩媚的身姿，善于用姿色迷惑敌人，缓慢敌人的步伐", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[110] =
	{   
		id = 110, 
		simplified_chinese = "李靖之子，飞出的乾坤圈会来回攻击敌人", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[111] =
	{   
		id = 111, 
		simplified_chinese = "龙王之女，善于凝结水滴，攻击四面八方的敌人", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[112] =
	{   
		id = 112, 
		simplified_chinese = "地府之首，横扫半圈，有机率震慑敌人，传说还会发出死亡波动", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[113] =
	{   
		id = 113, 
		simplified_chinese = "孙悟空的结拜大哥，体格强健，脾气暴躁;被动：被攻击时，有机率触发一个护盾", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[114] =
	{   
		id = 114, 
		simplified_chinese = "天神之一，大脚一震，四方皆动荡，有效阻止敌人的前进", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[115] =
	{   
		id = 115, 
		simplified_chinese = "前身卷帘大将军，别看我呆，今生我要做个爆发力选手（能力不祥）", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[116] =
	{   
		id = 116, 
		simplified_chinese = "哪吒之父，宝塔一出，血量低于x%的敌人，魂魄就会被宝塔摄取", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[117] =
	{   
		id = 117, 
		simplified_chinese = "天庭第一勇将，传说没人能逃出他的法眼，可以穿透世间万物", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[118] =
	{   
		id = 118, 
		simplified_chinese = "最毒妇人心，使攻击目标的同时，持续毒素伤害一段时间", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[119] =
	{   
		id = 119, 
		simplified_chinese = "牛魔王的妻子，芭蕉扇一出，飓风即起", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[120] =
	{   
		id = 120, 
		simplified_chinese = "虽然老夫有九个头，但仅用五个头，足以对付多个敌人", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[121] =
	{   
		id = 121, 
		simplified_chinese = "双锤碰一下，方圆百里全被冰封;受到攻击时，敌人被冰冻在原地", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[201] =
	{   
		id = 201, 
		simplified_chinese = "外星人留下的蛋蛋，传说它会爆炸", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[202] =
	{   
		id = 202, 
		simplified_chinese = "镇元大仙所种植，仙气横溢，能为你生产法力", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[203] =
	{   
		id = 203, 
		simplified_chinese = "佛家七宝之一，散发出的光芒可使炮塔增强力量", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[204] =
	{   
		id = 204, 
		simplified_chinese = "观世音菩萨法宝之一，一铃烈火，二铃寒冰，三铃剧毒", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[205] =
	{   
		id = 205, 
		simplified_chinese = "太上老君法宝之一，传说能瞬间秒杀任何敌人", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[206] =
	{   
		id = 206, 
		simplified_chinese = "阴阳二气之宝，阳为灼烧大地，阴为冰封万物", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[301] =
	{   
		id = 301, 
		simplified_chinese = "龙宫门将，我是虾兵", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[302] =
	{   
		id = 302, 
		simplified_chinese = "龙宫门将，我是蟹将", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[303] =
	{   
		id = 303, 
		simplified_chinese = "龙宫丞相，我是龟丞相", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[304] =
	{   
		id = 304, 
		simplified_chinese = "龙宫百姓，我是海螺", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[305] =
	{   
		id = 305, 
		simplified_chinese = "龙宫守护兽，我是大章鱼", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[306] =
	{   
		id = 306, 
		simplified_chinese = "龙宫百姓，我是海星", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[307] =
	{   
		id = 307, 
		simplified_chinese = "龙王宠物，我是蓝鲸", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[308] =
	{   
		id = 308, 
		simplified_chinese = "地府使者，我是黑无常", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[309] =
	{   
		id = 309, 
		simplified_chinese = "地府使者，我是白无常", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[310] =
	{   
		id = 310, 
		simplified_chinese = "地府使者，我是牛头", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[311] =
	{   
		id = 311, 
		simplified_chinese = "地府使者，我是马面", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[312] =
	{   
		id = 312, 
		simplified_chinese = "地府神兽，我是谛听", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[313] =
	{   
		id = 313, 
		simplified_chinese = "地府亡灵，我是鬼魂", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[314] =
	{   
		id = 314, 
		simplified_chinese = "地府亡灵，我是骷髅人", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[315] =
	{   
		id = 315, 
		simplified_chinese = "天庭士卒，我是天兵大叔", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[316] =
	{   
		id = 316, 
		simplified_chinese = "天庭宫女，我是神仙姐姐", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[317] =
	{   
		id = 317, 
		simplified_chinese = "天庭神犬，我是哮天犬", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[318] =
	{   
		id = 318, 
		simplified_chinese = "天庭将领，我是巨灵神", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[319] =
	{   
		id = 319, 
		simplified_chinese = "嫦娥宠物，我是玉兔", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[320] =
	{   
		id = 320, 
		simplified_chinese = "我来自弼马温，我是天马", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[321] =
	{   
		id = 321, 
		simplified_chinese = "天庭灵物，我是小灵狐", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[322] =
	{   
		id = 322, 
		simplified_chinese = "我是过街不会被打的萌鼠", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[323] =
	{   
		id = 323, 
		simplified_chinese = "森林之王，我是虎先锋", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[324] =
	{   
		id = 324, 
		simplified_chinese = "我是黑豹，吃饱了，跑不动了", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[325] =
	{   
		id = 325, 
		simplified_chinese = "我是树精，小心我的叶子", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[326] =
	{   
		id = 326, 
		simplified_chinese = "我是白熊，身子痒痒的", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[327] =
	{   
		id = 327, 
		simplified_chinese = "我是白蛇，还我许仙", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[328] =
	{   
		id = 328, 
		simplified_chinese = "我是猩猩，我将掀起一场世界大战", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[401] =
	{   
		id = 401, 
		simplified_chinese = "保护唐僧不受任何伤害", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[402] =
	{   
		id = 402, 
		simplified_chinese = "清除关卡中所有建筑物", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[403] =
	{   
		id = 403, 
		simplified_chinese = "不能让怪物消灭任何一个炮塔", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[404] =
	{   
		id = 404, 
		simplified_chinese = "清除%d个%s", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[405] =
	{   
		id = 405, 
		simplified_chinese = "在%d秒内清除%d个%s", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[406] =
	{   
		id = 406, 
		simplified_chinese = "使用%s消灭%d个怪物", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[407] =
	{   
		id = 407, 
		simplified_chinese = "在%d秒内使用%s消灭%d个怪物", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[408] =
	{   
		id = 408, 
		simplified_chinese = "在%d秒内获得%d法力", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[409] =
	{   
		id = 409, 
		simplified_chinese = "在%d秒内找到%d个隐藏在建筑物中的%", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[410] =
	{   
		id = 410, 
		simplified_chinese = "成功建造%d个满级%s", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[411] =
	{   
		id = 411, 
		simplified_chinese = "使用%d次%s", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[412] =
	{   
		id = 412, 
		simplified_chinese = "关卡中%s英雄的数量不超过%d个", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[503] =
	{   
		id = 503, 
		simplified_chinese = "摧毁场景中的道具，会获得额外的法力！", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[504] =
	{   
		id = 504, 
		simplified_chinese = "合理的搭配阵容可以使你更容易过关。", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[505] =
	{   
		id = 505, 
		simplified_chinese = "合理使用人参果可以为你带来更多的法力。", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[506] =
	{   
		id = 506, 
		simplified_chinese = "可以轻碰对你有威胁的怪物，从而降低危险。", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[507] =
	{   
		id = 507, 
		simplified_chinese = "暂停时仍可建造或升级英雄哦～", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[508] =
	{   
		id = 508, 
		simplified_chinese = "危急时使用道具可以让你度过难关。", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[509] =
	{   
		id = 509, 
		simplified_chinese = "英雄只有在搭配上合适的位置时才能发挥出他的作用。", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[510] =
	{   
		id = 510, 
		simplified_chinese = "获得更多强大的法宝，能帮你容易取得胜利。", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[511] =
	{   
		id = 511, 
		simplified_chinese = "合理的建造带特殊效果的英雄会使战斗轻松很多哦～", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[512] =
	{   
		id = 512, 
		simplified_chinese = "带有概率的英雄运气好能帮你很轻松放的取得胜利。", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[513] =
	{   
		id = 513, 
		simplified_chinese = "不同英雄升级后变化的效果不同，在关键时刻了解这个能发挥很大作用。", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[514] =
	{   
		id = 514, 
		simplified_chinese = "英雄升级时属性会有所提升哦！", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[515] =
	{   
		id = 515, 
		simplified_chinese = "英雄升级后会补满血量哦！", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[516] =
	{   
		id = 516, 
		simplified_chinese = "当爆出稀有法宝的时候，要抓紧机会哦", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[517] =
	{   
		id = 517, 
		simplified_chinese = "其实，怪物在它的攻击范围内，会优先攻击最大生命值较大的炮塔", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[518] =
	{   
		id = 518, 
		simplified_chinese = "我是猪", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[519] =
	{   
		id = 519, 
		simplified_chinese = "你知道就好", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[520] =
	{   
		id = 520, 
		simplified_chinese = "你是帅哥", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[601] =
	{   
		id = 601, 
		simplified_chinese = "那当然", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[602] =
	{   
		id = 602, 
		simplified_chinese = "", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[603] =
	{   
		id = 603, 
		simplified_chinese = "", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[604] =
	{   
		id = 604, 
		simplified_chinese = "", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[605] =
	{   
		id = 605, 
		simplified_chinese = "", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[606] =
	{   
		id = 606, 
		simplified_chinese = "", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[607] =
	{   
		id = 607, 
		simplified_chinese = "", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[608] =
	{   
		id = 608, 
		simplified_chinese = "", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[609] =
	{   
		id = 609, 
		simplified_chinese = "", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[610] =
	{   
		id = 610, 
		simplified_chinese = "", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[611] =
	{   
		id = 611, 
		simplified_chinese = "", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[612] =
	{   
		id = 612, 
		simplified_chinese = "", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[613] =
	{   
		id = 613, 
		simplified_chinese = "", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[614] =
	{   
		id = 614, 
		simplified_chinese = "", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[615] =
	{   
		id = 615, 
		simplified_chinese = "", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[616] =
	{   
		id = 616, 
		simplified_chinese = "", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[617] =
	{   
		id = 617, 
		simplified_chinese = "", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[618] =
	{   
		id = 618, 
		simplified_chinese = "", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[619] =
	{   
		id = 619, 
		simplified_chinese = "", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[620] =
	{   
		id = 620, 
		simplified_chinese = "", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[621] =
	{   
		id = 621, 
		simplified_chinese = "", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[622] =
	{   
		id = 622, 
		simplified_chinese = "", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[623] =
	{   
		id = 623, 
		simplified_chinese = "", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[624] =
	{   
		id = 624, 
		simplified_chinese = "", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[625] =
	{   
		id = 625, 
		simplified_chinese = "", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[626] =
	{   
		id = 626, 
		simplified_chinese = "", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[627] =
	{   
		id = 627, 
		simplified_chinese = "", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[628] =
	{   
		id = 628, 
		simplified_chinese = "", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[629] =
	{   
		id = 629, 
		simplified_chinese = "", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[630] =
	{   
		id = 630, 
		simplified_chinese = "", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[631] =
	{   
		id = 631, 
		simplified_chinese = "", 
		traditional_chinese = "", 
		English = ""
	}
StringConfig[632] =
	{   
		id = 632, 
		simplified_chinese = "", 
		traditional_chinese = "", 
		English = ""
	}


function StringConfig.id(id)
	return StringConfig[id].id
end

function StringConfig.simplified_chinese(id)
	return StringConfig[id].simplified_chinese
end

function StringConfig.traditional_chinese(id)
	return StringConfig[id].traditional_chinese
end

function StringConfig.English(id)
	return StringConfig[id].English
end

        